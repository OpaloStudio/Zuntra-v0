<div class="container-fluid dashboard">
    <div class="scrollox">
        <div class="row">
            <div class="col-6 DashIzquierda">

                <div class="scrollIzquierda">
                    <div class="wrap">
                        <div class="card cardBlanca">
                            <div class="card-body text-center">
                                Total de Reservas<br><br>
                                <p id="reservacionesTotales">0 / 0</p>
                            </div>
                        </div>
                        <div class="card cardBlanca">
                            <div class="card-body text-center">
                                Reservaciones simples<br><br>
                                <p id="reservacionesSimples">0 / 0</p>
                            </div>
                        </div>
                        <div class="card cardBlanca">
                            <div class="card-body text-center">
                                Reservaciones de Grupo<br><br>
                                <p id="reservacionesGrupo">0 / 0</p>
                            </div>
                        </div>
                        <div class="card cardBlanca">
                            <div class="card-body text-center">
                                Reservación de Cumpleaños<br><br>
                                <p id="reservacionesCumple">0 / 0</p>
                            </div>
                        </div>
                        <br><br>
                    </div>
                </div>

            </div>
            <div class="col-6 DashDerecha">
                <div class="scrollIzquierda">
                    <div class="wrap" id="rps">
                        <!--
                        <div class="card cardNegra mb-3" style="max-width: 540px;">
                            <div class="row no-gutters">
                                <div class="col-md-4">
                                    <img src="vistas/img/logo.png" class="card-img" alt="profile-pic">
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body">
                                        <h5 class="card-title">Nombre Monito</h5>
                                        <p class="card-text">30/50
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card cardNegra mb-3" style="max-width: 540px;">
                            <div class="row no-gutters">
                                <div class="col-md-4">
                                    <img src="vistas/img/logo.png" class="card-img" alt="profile-pic">
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body">
                                        <h5 class="card-title">Nombre Monito</h5>
                                        <p class="card-text">30/50
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card cardNegra mb-3" style="max-width: 540px;">
                            <div class="row no-gutters">
                                <div class="col-md-4">
                                    <img src="vistas/img/logo.png" class="card-img" alt="profile-pic">
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body">
                                        <h5 class="card-title">Nombre Monito</h5>
                                        <p class="card-text">30/50
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card cardNegra mb-3" style="max-width: 540px;">
                            <div class="row no-gutters">
                                <div class="col-md-4">
                                    <img src="vistas/img/logo.png" class="card-img" alt="profile-pic">
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body">
                                        <h5 class="card-title">Nombre Monito</h5>
                                        <p class="card-text">30/50
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card cardNegra mb-3" style="max-width: 540px;">
                            <div class="row no-gutters">
                                <div class="col-md-4">
                                    <img src="vistas/img/logo.png" class="card-img" alt="profile-pic">
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body">
                                        <h5 class="card-title">Nombre Monito</h5>
                                        <p class="card-text">30/50
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        -->
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>