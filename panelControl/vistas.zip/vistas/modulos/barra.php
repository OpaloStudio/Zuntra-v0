<ul class="nav  barra">
  <li class="nav-item tooltip-dorado" aria-label="Dashboard" data-balloon-pos="down">
    <a class="nav-link linky" id="1" href="?page=2" onclick="selector(1)"><i class="fas fa-home iconito"></i></a>
  </li>
  <li class="nav-item tooltip-dorado" aria-label="Rps" data-balloon-pos="down">
    <a class="nav-link linky" id="2" href="?page=3"><i class="fas fa-user-check iconito"></i></a>
  </li>
  <li class="nav-item tooltip-dorado" aria-label="Usuarios" data-balloon-pos="down">
    <a class="nav-link linky" id="3" href="?page=4"><i class="fas fa-address-book iconito"></i></a>
  </li>
  <li class="nav-item tooltip-dorado" aria-label="Reservaciones" data-balloon-pos="down">
    <a class="nav-link linky " id="4" href="?page=5" ><i class="fas fa-clipboard-list iconito"></i></a>
  </li>
  <li class="nav-item tooltip-dorado" aria-label="Configuración" data-balloon-pos="down">
    <a class="nav-link linky " id="5" href="?page=7" ><i class="fas fa-cog iconito"></i></a>
  </li>
</ul>